files {
    'index.html',
    'credit.png',
    'loadscreen.jpg',
    'logo.png',
    'options.png',
    'overlay-menu.png',
    'quit.png',
    'siteweb.png',
    'start.png',
    'style.css',
	'music/Loading.ogg'
}

loadscreen 'index.html'

resource_manifest_version '77731fab-63ca-442c-a67b-abc70f28dfa5'